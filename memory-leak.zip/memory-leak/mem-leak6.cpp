#include <iostream>

using namespace std;


int main(){
   int x[1024];
   x[1024]= 42;
   int *p= new int[1024];
   //p= p+52;
   delete []p;
   return 0;
}
